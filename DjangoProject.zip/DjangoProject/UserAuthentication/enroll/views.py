from django.shortcuts import render
from .forms import SignUpForm
from django.contrib import messages
# Create your views here.
def show(request):
    if request.method  =='POST':
        fm = SignUpForm(request.POST)
        if fm.is_valid():
          fm.save()
          messages.success(request, 'form has been submitted')
    else:
        fm = SignUpForm()
    return render(request, 'core/p1.html' , {'form':fm}) 