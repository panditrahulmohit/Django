from django.shortcuts import render
from .models import Student, Teacher
from django.db.models import Q
# Create your views here.
def home(request):
     student_data = Student.objects.all()
     print("Return:", student_data)
     print()
     print("SQL Query:", student_data.query)
     return render(request, 'core/student_data.html', {'students':student_data})