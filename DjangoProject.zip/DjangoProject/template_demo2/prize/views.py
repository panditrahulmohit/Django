from django.shortcuts import render

# Create your views here.
def prize(request):
    return render(request, 'cor/p2.html')