from django.urls import path
from . import views
urlpatterns = [
    path('pzdj/', views.prize),
]
