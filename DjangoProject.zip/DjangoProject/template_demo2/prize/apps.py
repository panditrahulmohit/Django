from django.apps import AppConfig


class PrizeConfig(AppConfig):
    name = 'prize'
