from django.apps import AppConfig


class PenConfig(AppConfig):
    name = 'pen'
