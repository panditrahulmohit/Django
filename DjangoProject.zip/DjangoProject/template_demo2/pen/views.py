from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def pen(request):
    return render(request, 'cor/p1.html')