from django import http
from django.shortcuts import render, HttpResponse

# Create your views here.
def display(request):
    return HttpResponse("this is my view page")