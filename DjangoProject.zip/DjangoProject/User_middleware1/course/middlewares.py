from django.shortcuts import HttpResponse
class Rahul:    
    def __init__(self, get_response):
        self.get_response= get_response
        print("one time initallization")
    
    def __call__(self, request):
        print("this is before view")
    
        response= self.get_response(request)
        # print("this is after view ")
        print("source of request is:", request.META('HTTPS_USER_AGENT'))
        return response