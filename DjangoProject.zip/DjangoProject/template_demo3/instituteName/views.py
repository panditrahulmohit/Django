from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def instituteName(request):
    return render(request, 'core/p2.html')