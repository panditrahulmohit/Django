from django.apps import AppConfig


class InstitutenameConfig(AppConfig):
    name = 'instituteName'
