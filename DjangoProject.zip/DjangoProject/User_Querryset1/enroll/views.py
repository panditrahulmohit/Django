from django.shortcuts import render
from .models import Student,Teacher
from django.db.models import Q
# Create your views here.
def home(request):
    # student_data = Student.objects.all()

    # student_data = Student.objects.filter(marks=90)

    # student_data = Student.objects.exclude(marks=50)

    # student_data = Student.objects.order_by('marks')
    # student_data = Student.objects.order_by('-marks')
    # student_data = Student.objects.order_by('name')
    # Student_data = Student.objects.order_by('?')

    # student_data = Student.objects.order_by('id').reverse()[0:5]

    # student_data = Student.objects.values_list()
    #   student_data = Student.objects.values_list('id', 'marks')
    #   student_data = Student.objects.vlaues_list('id', 'name', named = True)
    # student_data = Student.objects.using(defaults)
    # student_data = Student.objects.dates('pass_date', 'month')

    ########################################## second table (Teacher):-
    # qs1 = Student.objects.values_list('id', 'name', named= True)
    # qs2 = Student.objects.values_list('id', 'name', named= True)
    # student_data= qs1 union (qs2, all=True)

    # qs1 = Student.objects.values_list('id', 'name', named=True)
    # qs2 = Student.objects.values_list('id', 'name', named=True)
    # student_data = qs1.intersection(qs2)
    
    # qs1 = Student.objects.values_list('id', 'name', named=True)
    # qs2 = Student.objects.values_list('id', 'name', named=True)
    # student_data = qs1.diffrence(qs2)

    ######################### NOT/ OR
    # student_data = Student.objects.filter(id=6) & Student.objects.filter(roll=106)
    # student_data = Student.objects.filter(id=6, roll=106)
    # student_data = Student.objects.filter(Q(id=6) & Q(roll=106))

    # student_data = Student.objects.filter(id=6) | Student.objects.filter(roll=107)
    student_data = Student.objects.filter(Q(id=6) | Q(roll=108))

    print('return', student_data)
    print()
    print('sql querry', student_data.query)
    return render(request, 'core/home.html', {'student_data': student_data})