from django.shortcuts import render

# Create your views here.
def fees(request):
    return render(request, 'core/p2.html')