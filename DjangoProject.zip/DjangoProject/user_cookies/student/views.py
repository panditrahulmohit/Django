from django.shortcuts import render
from datetime import datetime, timedelta

# set cookie. 
def set_cookie(request):
 reponse = render(request, 'student/setcookie.html')
 reponse.set_cookie('name': 'Rahul sharma', expires=datetime.utcnow()+timedelta(days=2))
 return reponse

#get cookie
def get_cookie(request):
    name= request.COOKIES.get('name')
    return render(request, 'core/get.html', {'name': name})

# delete cookie
def del_cookie(request):
    response =render(request, 'core/delete.html')
    response.delete_cookie('name')
    return response
 